# Pyarmor 9.2.7 (basic), 009868, 2026-10-19T13:59:29.154966
from .pyarmor_runtime import __pyarmor__
