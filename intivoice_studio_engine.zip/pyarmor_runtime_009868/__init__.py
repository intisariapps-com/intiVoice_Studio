# Pyarmor 9.2.7 (basic), 009868, 2026-10-19T13:50:11.632784
from .pyarmor_runtime import __pyarmor__
