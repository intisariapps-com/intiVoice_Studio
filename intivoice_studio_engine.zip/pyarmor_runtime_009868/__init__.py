# Pyarmor 9.2.7 (basic), 009868, 2026-09-18T21:59:10.780156
from .pyarmor_runtime import __pyarmor__
